import os
import time
import json
import threading
import winreg as reg
import matplotlib.pyplot as plt
from PySide6 import QtWidgets, QtCore
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# Backend
temp_dir = os.path.join(os.environ.get('SystemRoot'), 'Temp')
additional_dir = os.path.join(os.environ.get('TEMP'))
delete_at_reboot_file = 'delete_at_reboot.txt'
prefetch_dir = os.path.join(os.environ.get('SystemRoot'), 'Prefetch')
stop_timer_flag = False
scheduled_time_exists = False

def list_temp_files():
    temp_files = [f for f in os.listdir(temp_dir) if os.path.isfile(os.path.join(temp_dir, f))]
    additional_files = [f for f in os.listdir(additional_dir) if os.path.isfile(os.path.join(additional_dir, f))]
    prefetch_files = [f for f in os.listdir(prefetch_dir) if os.path.isfile(os.path.join(prefetch_dir, f))]
    return temp_files + additional_files + prefetch_files

def delete_temp_files(files):
    for file in files:
        try:
            if os.path.isfile(os.path.join(temp_dir, file)):
                os.remove(os.path.join(temp_dir, file))
            elif os.path.isfile(os.path.join(additional_dir, file)):
                os.remove(os.path.join(additional_dir, file))
            elif os.path.isfile(os.path.join(prefetch_dir, file)):
                os.remove(os.path.join(prefetch_dir, file))
        except PermissionError:
            pass

def schedule_deletion_files(files, delay_seconds):
    with open(delete_at_reboot_file, 'w') as f:
        f.write(f"{int(time.time()) + delay_seconds}\n")
        f.write("\n".join(files))

def remove_scheduled_deletion():
    global stop_timer_flag, scheduled_time_exists
    if os.path.exists(delete_at_reboot_file):
        os.remove(delete_at_reboot_file)
        stop_timer_flag = True
        scheduled_time_exists = False

def load_timer_data():
    timer_data_file = 'timer_data.json'
    if os.path.exists(timer_data_file):
        with open(timer_data_file, 'r') as f:
            data = json.load(f)
            return data['end_time'], data['stop_timer_flag']
    return None, None

#Graph
class GraphCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(5, 2), dpi=100)
        self.ax = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)
        self.ax.set_ylabel('Size (MB)')
        self.ax.set_xticks([])  # Hide x-ticks

    def plot(self, size):
        self.ax.clear()  # Clear previous graph
        self.ax.bar(['Temporary Files'], [size], color='blue')
        self.ax.set_ylim(0, 1000)  # Adjust y-axis limit as needed
        self.draw()

# Frontend using PySide6
class AutoTempCleanerApp(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Auto Temp Cleaner App")
        self.setMinimumSize(1080, 720)
        self.setGeometry(200, 200, 1280, 720)
        self.setStyleSheet("background-color: #2C2C2C;")
        self.create_widgets()
        self.remaining_time_label = QtWidgets.QLabel("", self)
        self.load_timer_data()
        self.scheduling_active = False  # Track if scheduling is active

        # Create graph canvas
        self.graph_canvas = GraphCanvas(self)
        self.graph_canvas.setGeometry(20, 460, 680, 100)

        # Create graph label
        self.graph_label = QtWidgets.QLabel("Temporary Files Storage Usage (Try to keep it below 1gb!!)", self)
        self.graph_label.setGeometry(20, 430, 680, 30)
        self.graph_label.setStyleSheet("color: white; font-family: 'Courier New'; font-size: 16px;")
        self.graph_label.setAlignment(QtCore.Qt.AlignCenter)
        QtCore.QTimer.singleShot(3000, lambda: self.notification_label.clear())

        self.update_graph()

    def create_widgets(self):
        self.frame = QtWidgets.QFrame(self)
        self.frame.setStyleSheet("background-color: #2C2C2C; border-radius: 10px;")
        self.frame.setGeometry(50, 50, 680, 440)

        self.label = QtWidgets.QLabel("Select an option:", self.frame)
        self.label.setGeometry(20, 20, 200, 30)
        self.label.setStyleSheet("color: white; font-family: 'Courier New'; font-size: 16px;")

        self.delete_button = QtWidgets.QPushButton("Delete Files Immediately", self.frame)
        self.delete_button.setGeometry(20, 60, 640, 50)
        self.delete_button.setStyleSheet(self.button_style())
        self.delete_button.clicked.connect(self.delete_files)

        self.schedule_button = QtWidgets.QPushButton("Schedule Deletion of Temporary Files", self.frame)
        self.schedule_button.setGeometry(20, 130, 640, 50)
        self.schedule_button.setStyleSheet(self.button_style())
        self.schedule_button.clicked.connect(self.display_schedule_options)

        self.stop_button = QtWidgets.QPushButton("Stop Scheduled Deletion", self.frame)
        self.stop_button.setGeometry(20, 200, 640, 50)
        self.stop_button.setStyleSheet(self.button_style())
        self.stop_button.clicked.connect(self.stop_scheduled_deletion)

        # Adding "Return to Home" button initially (hidden)
        self.return_button = QtWidgets.QPushButton("Return to Home", self.frame)
        self.return_button.setGeometry(20, 270, 640, 50)
        self.return_button.setStyleSheet(self.button_style())
        self.return_button.setVisible(False)
        self.return_button.clicked.connect(self.return_to_home)
        
        # Notification label
        self.notification_label = QtWidgets.QLabel("", self)
        self.notification_label.setGeometry(330, 20, 640, 30)
        self.notification_label.setStyleSheet("color: yellow; font-family: 'Courier New'; font-size: 16px;")
        self.notification_label.setAlignment(QtCore.Qt.AlignCenter)


    def button_style(self):
        return """
        QPushButton {
            background-color: #7D3C98;
            color: white;
            font-family: 'Courier New';
            font-size: 25px;
            border-radius: 10px;
            border: 2px solid #5C2A7E;
        }
        QPushButton:hover {
            background-color: #5C2A7E;
            border: 2px solid #7D3C98;
        }
        QPushButton:pressed {
            background-color: #4B1F60;
            border: 2px solid #7D3C98;
        }
        """

    def display_schedule_options(self):
        if self.scheduling_active:
            return  # Notification system removed

        self.label.setText("Select the delay option: ")
        # Update buttons for scheduling options
        self.delete_button.setText("1. Delete after one day")
        self.delete_button.clicked.disconnect()
        self.delete_button.clicked.connect(lambda: self.schedule_deletion(1))

        self.schedule_button.setText("2. Delete after one week")
        self.schedule_button.clicked.disconnect()
        self.schedule_button.clicked.connect(lambda: self.schedule_deletion(7))

        self.stop_button.setText("3. Delete after one month")
        self.stop_button.clicked.disconnect()
        self.stop_button.clicked.connect(lambda: self.schedule_deletion(30))

        # Show the "Return to Home" button
        self.return_button.setVisible(True)

    def return_to_home(self):
        # Reset the UI to show the original options on the main menu
        self.label.setText("Select an option:")
        
        self.delete_button.setText("Delete Files Immediately")
        self.delete_button.clicked.disconnect()
        self.delete_button.clicked.connect(self.delete_files)

        self.schedule_button.setText("Schedule Deletion of Temporary Files")
        self.schedule_button.clicked.disconnect()
        self.schedule_button.clicked.connect(self.display_schedule_options)

        self.stop_button.setText("Stop Scheduled Deletion")
        self.stop_button.clicked.disconnect()
        self.stop_button.clicked.connect(self.stop_scheduled_deletion)

        # Hide the "Return to Home" button after returning to home
        self.return_button.setVisible(False)

    def load_timer_data(self):
        end_time, stop_timer_flag = load_timer_data()
        if end_time and not stop_timer_flag:
            threading.Thread(target=self.display_remaining_time, args=(end_time,)).start()

    def display_remaining_time(self, end_time):
        global stop_timer_flag
        while time.time() < end_time and not stop_timer_flag:
            remaining_time = end_time - time.time()
            hours, remainder = divmod(remaining_time, 3600)
            minutes, seconds = divmod(remainder, 60)
            time_str = "{:02}:{:02}:{:02}".format(int(hours), int(minutes), int(seconds))
            self.remaining_time_label.setText(f"Time remaining for deletion: {time_str}")
            self.remaining_time_label.setStyleSheet("color: white; font-family: 'Courier New'; font-size: 16px;")
            time.sleep(1)

        if not stop_timer_flag:
            self.remaining_time_label.setText("Deleting temporary files...")
            temp_files = list_temp_files()
            delete_temp_files(temp_files)
            self.remaining_time_label.setText("")  # Removed notification text

    def delete_files(self):
        temp_files = list_temp_files()
        delete_temp_files(temp_files)
        self.display_notification("Deleted temporary files successfully")
        QtCore.QTimer.singleShot(3000, lambda: self.notification_label.clear())


    def stop_scheduled_deletion(self):
        global scheduled_time_exists
        if not self.scheduling_active:
        # Display an error message since no deletion is scheduled
            self.display_notification("Error: No scheduled deletion to stop.")
            return  # Exit the function
    
        # If a deletion is scheduled, proceed to remove it
        remove_scheduled_deletion()
        self.scheduling_active = False  # Reset scheduling active status
    
        # Remove the application from startup
        self.remove_from_startup()
        
        # Display success message after stopping the deletion
        self.display_notification("Scheduled deletion has been successfully stopped.")
        QtCore.QTimer.singleShot(3000, lambda: self.notification_label.clear())

    def schedule_deletion(self, days):
        if self.scheduling_active:
            # Display an error message since deletion is already scheduled
            self.display_notification("Error: Deletion is already scheduled.")
            return  # Exit the function
        QtCore.QTimer.singleShot(3000, lambda: self.notification_label.clear())
        
        delay_seconds = days * 86400  # Convert days to seconds
        temp_files = list_temp_files()
        schedule_deletion_files(temp_files, delay_seconds)
        self.remaining_time_label.setText("")  # Removed notification text

        # Add the application to startup
        self.add_to_startup()

        self.scheduling_active = True  # Set scheduling active status

        # Display success message after scheduling deletion
        self.display_notification(f"Deletion scheduled successfully for {days} day(s).")
        QtCore.QTimer.singleShot(3500, lambda: self.notification_label.clear())

    # Method for in-app notifications
    def display_notification(self, message):
        # Update this method to show the message in your UI
        self.notification_label.setText(message)


    def add_to_startup(self):
        key = reg.OpenKey(reg.HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, reg.KEY_SET_VALUE)
        reg.SetValueEx(key, "AutoTempCleanerApp", 0, reg.REG_SZ, f'"{os.path.abspath(__file__)}"')
        reg.CloseKey(key)

    def remove_from_startup(self):
        key = reg.OpenKey(reg.HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", 0, reg.KEY_SET_VALUE)
        reg.DeleteValue(key, "AutoTempCleanerApp")
        reg.CloseKey(key)

    def get_temp_size(self):
        total_size = 0
        directories = [temp_dir, additional_dir, prefetch_dir]  # List of temporary directories

        for directory in directories:
            try:
                for f in os.listdir(directory):
                    file_path = os.path.join(directory, f)
                    if os.path.isfile(file_path):  # Check if it's a file
                        total_size += os.path.getsize(file_path)
            except Exception as e:
                print(f"Error accessing {directory}: {e}")

        return total_size / (1024 * 1024)  # Convert to MB


    def update_graph(self):
        size = self.get_temp_size()
        self.graph_canvas.plot(size)
        QtCore.QTimer.singleShot(5000, self.update_graph)  # Update every 5 seconds

    def resizeEvent(self, event):
        # Adjust dimensions of the frame and buttons on resize
        self.frame.setGeometry(10, 10, self.width() - 20, self.height() - 20)
        self.delete_button.setGeometry(20, 60, self.frame.width() - 40, 50)
        self.schedule_button.setGeometry(20, 130, self.frame.width() - 40, 50)
        self.stop_button.setGeometry(20, 200, self.frame.width() - 40, 50)
        self.return_button.setGeometry(20, 270, self.frame.width() - 40, 50)
    
    def show_notification(self, message):
        self.notification_label.setText(message)
        # Hide the notification after a certain time
        QtCore.QTimer.singleShot(5000, lambda: self.notification_label.clear())

if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    window = AutoTempCleanerApp()
    window.show()
    app.exec()